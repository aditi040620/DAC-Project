package com.GetYourArtist.ArtistManagment.services.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.GetYourArtist.ArtistManagment.dtos.BlogDTO;
import com.GetYourArtist.ArtistManagment.entities.Blog;
import com.GetYourArtist.ArtistManagment.repositories.BlogRepository;
import com.GetYourArtist.ArtistManagment.services.BlogService;

@Service
public class BlogImpl implements BlogService {

	@Autowired
	private BlogRepository blogRepository;

	@Autowired
	private ModelMapper mapper;

	@Override
	public BlogDTO createBlog(BlogDTO blogDTO) {
		// Convert BlogDTO to Blog entity
		Blog blog = dtoToEntity(blogDTO);

		// Save the blog entity to the repository
		Blog savedBlog = blogRepository.save(blog);

		// Convert saved Blog entity to BlogDTO and return
		return entityToDto(savedBlog);
	}

	@Override
	public BlogDTO updateBlog(BlogDTO blogDTO, String blogId) {
		// Find the existing blog by ID
		Blog existingBlog = blogRepository.findById(blogId)
				.orElseThrow(() -> new RuntimeException("Blog Not Found with ID: " + blogId));

		// Update the fields
		existingBlog.setTitle(blogDTO.getTitle());
		existingBlog.setDescription(blogDTO.getDescription());
		existingBlog.setImages(blogDTO.getImages());
		existingBlog.setCreatedAt(blogDTO.getCreatedAt());
		existingBlog.setUpdatedAt(blogDTO.getUpdatedAt());

		// Save the updated blog
		Blog updatedBlog = blogRepository.save(existingBlog);

		// Convert updated Blog entity to BlogDTO and return
		return entityToDto(updatedBlog);
	}

	@Override
	public void deleteBlog(String blogId) {
		// Find the blog by ID
		Blog blog = blogRepository.findById(blogId)
				.orElseThrow(() -> new RuntimeException("Blog Not Found with ID: " + blogId));

		// Delete the blog entity from the repository
		blogRepository.delete(blog);
	}

	@Override
	public BlogDTO getBlogById(String blogId) {
		// Find the blog by ID
		Blog blog = blogRepository.findById(blogId)
				.orElseThrow(() -> new RuntimeException("Blog not found with ID: " + blogId));

		// Convert Blog entity to BlogDTO and return
		return entityToDto(blog);
	}

	@Override
	public List<BlogDTO> getAllBlogs() {
		// Retrieve all blogs from the repository
		List<Blog> blogs = blogRepository.findAll();

		// Convert list of Blog entities to list of BlogDTOs
		return blogs.stream().map(this::entityToDto).collect(Collectors.toList());
	}

	@Override
	public List<BlogDTO> getBlogsByAuthor(String author) {
		// Find blogs by author ID
		List<Blog> blogs = blogRepository.findByAuthorName(author);

		// Convert list of Blog entities to list of BlogDTOs
		return blogs.stream().map(this::entityToDto).collect(Collectors.toList());
	}

	private Blog dtoToEntity(BlogDTO blogDTO) {
		return mapper.map(blogDTO, Blog.class);
	}

	private BlogDTO entityToDto(Blog blog) {
		return mapper.map(blog, BlogDTO.class);
	}

}
