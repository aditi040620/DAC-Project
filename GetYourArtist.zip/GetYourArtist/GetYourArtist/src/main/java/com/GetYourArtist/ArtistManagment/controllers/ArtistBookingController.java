package com.GetYourArtist.ArtistManagment.controllers;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.GetYourArtist.ArtistManagment.dtos.ArtistBookingDTO;
import com.GetYourArtist.ArtistManagment.services.ArtistBookingService;

@RestController
@RequestMapping("/api/bookings")
public class ArtistBookingController {

	@Autowired
	private ArtistBookingService bookingService;

	// Create a new booking
	@PostMapping
	public ResponseEntity<ArtistBookingDTO> createBooking(@RequestBody ArtistBookingDTO bookingDTO) {
		ArtistBookingDTO createdBooking = bookingService.createBooking(bookingDTO);
		return new ResponseEntity<>(createdBooking, HttpStatus.CREATED);
	}

	// Update an existing booking
	@PutMapping("/{bookingId}")
	public ResponseEntity<ArtistBookingDTO> updateBooking(@PathVariable String bookingId,
			@RequestBody ArtistBookingDTO bookingDTO) {
		ArtistBookingDTO updatedBooking = bookingService.updateBooking(bookingDTO, bookingId);
		return new ResponseEntity<>(updatedBooking, HttpStatus.OK);
	}

	// Delete a booking by ID
	@DeleteMapping("/{bookingId}")
	public ResponseEntity<Void> deleteBooking(@PathVariable String bookingId) {
		bookingService.deleteBooking(bookingId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	// Get a booking by ID
	@GetMapping("/{bookingId}")
	public ResponseEntity<ArtistBookingDTO> getBookingById(@PathVariable String bookingId) {
		ArtistBookingDTO bookingDTO = bookingService.getBookingById(bookingId);
		return new ResponseEntity<>(bookingDTO, HttpStatus.OK);
	}

	// Get all bookings
	@GetMapping
	public ResponseEntity<List<ArtistBookingDTO>> getAllBookings() {
		List<ArtistBookingDTO> bookings = bookingService.getAllBookings();
		return new ResponseEntity<>(bookings, HttpStatus.OK);
	}

	// Get bookings by artist name
	@GetMapping("/artist/{firstName}")
	public ResponseEntity<List<ArtistBookingDTO>> getBookingsByArtistName(@PathVariable String firstName) {
		List<ArtistBookingDTO> bookings = bookingService.getBookingsByArtistName(firstName);
		return new ResponseEntity<>(bookings, HttpStatus.OK);
	}

	// Get bookings by user name
	@GetMapping("/user/{userName}")
	public ResponseEntity<List<ArtistBookingDTO>> getBookingsByUserName(@PathVariable String userName) {
		List<ArtistBookingDTO> bookings = bookingService.getBookingsByUserName(userName);
		return new ResponseEntity<>(bookings, HttpStatus.OK);
	}

	// Get bookings by status
	@GetMapping("/status/{status}")
	public ResponseEntity<List<ArtistBookingDTO>> getBookingsByStatus(@PathVariable String status) {
		List<ArtistBookingDTO> bookings = bookingService.getBookingsByStatus(status);
		return new ResponseEntity<>(bookings, HttpStatus.OK);
	}

	// Get bookings by artist name and status
	@GetMapping("/artist/{firstName}/status/{status}")
	public ResponseEntity<List<ArtistBookingDTO>> getBookingsByArtistNameAndStatus(@PathVariable String firstName,
			@PathVariable String status) {
		List<ArtistBookingDTO> bookings = bookingService.getBookingsByArtistNameAndStatus(firstName, status);
		return new ResponseEntity<>(bookings, HttpStatus.OK);
	}

	// Get bookings by user name and status
	@GetMapping("/user/{userName}/status/{status}")
	public ResponseEntity<List<ArtistBookingDTO>> getBookingsByUserNameAndStatus(@PathVariable String userName,
			@PathVariable String status) {
		List<ArtistBookingDTO> bookings = bookingService.getBookingsByUserNameAndStatus(userName, status);
		return new ResponseEntity<>(bookings, HttpStatus.OK);
	}

	// Get a booking by artist name and event date
	@GetMapping("/artist/{firstName}/event-date")
	public ResponseEntity<ArtistBookingDTO> getBookingByArtistNameAndEventDate(@PathVariable String firstName,
			@RequestParam("eventDate") LocalDateTime eventDate) {
		ArtistBookingDTO bookingDTO = bookingService.getBookingByArtistNameAndEventDate(firstName, eventDate);
		return new ResponseEntity<>(bookingDTO, HttpStatus.OK);
	}
}
