package com.GetYourArtist.ArtistManagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetYourArtistApplicationTests {

	@Test
	void contextLoads() {
	}

}
