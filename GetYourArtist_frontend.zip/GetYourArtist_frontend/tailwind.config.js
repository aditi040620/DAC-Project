/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}

// // FDF5F3
// // BE0905

// module.exports = {
//   theme: {
//     extend: {
//       colors: {
//         'primary-red': '#BE0905',
//         'bg-white':'#FDF5F3',
//       },
//     },
//   },
//   // Other Tailwind CSS configurations...
// };
