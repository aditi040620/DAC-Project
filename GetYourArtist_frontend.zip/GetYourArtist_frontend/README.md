<<<<<<< HEAD
Get Your Artist - Artist Booking and Mangement Website

Packages and Installation - 
    1.Create React App - npx create-react-app get-your-artist
    2.Install Tailwind CSS - https://tailwindcss.com/docs/installation
    3.Install React Router Dom - npm install react-router-dom
    4.Install Axios  - npm install axios react-router-dom
    4.Start your react app - npm start

Frameworks / libraries use - 
    1.TailwindCSS
    2.React Router Dom - for routing 
    3.Axios - for fetching data


Frontend -  React ,Tailwind Css
Backend - Spring Boot
Database - MySQL
API testing - Postman

Pages - 
•	User Login  - Sign In/Up
•	Home 
•	About Us + Contact Us
•	Get Your Artist
•	Book Artist
•	Register
•	Blogs
•	Chat
•	Feedback
=======
# GetYourArtist
Artist Mangement Website
>>>>>>> 7cc75a69c0f5a3502d6c25aca5fcece76847c3c9
